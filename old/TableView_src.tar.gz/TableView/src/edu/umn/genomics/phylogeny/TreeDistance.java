package edu.umn.genomics.phylogeny;

import javax.swing.tree.*;

public interface TreeDistance {
  public double getDistance();
  public void setDistance(double distance);
}

